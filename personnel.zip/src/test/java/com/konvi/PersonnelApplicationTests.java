package com.konvi;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonnelApplicationTests {

    @Test
    void contextLoads()
    {
        System.out.println("test on 8.31!");
    }

}
