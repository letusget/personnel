package com.konvi.service;

import com.konvi.entity.User;

/**
 * @author konvi
 * @version 1.0
 * @date 2021/9/9
 */
public interface IUserService
{
    public boolean verifyUser(User user);
}
